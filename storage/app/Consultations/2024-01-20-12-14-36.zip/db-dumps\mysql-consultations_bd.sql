
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `consultation_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultation_places` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `daira` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `consultation_places` WRITE;
/*!40000 ALTER TABLE `consultation_places` DISABLE KEYS */;
INSERT INTO `consultation_places` VALUES (2,'center abou tachfine tlemcen','abou tachfine tlemcen','043225511','043225512','34.91034926214029',' -1.31820049281958','tlemcen',NULL,'2024-01-11 08:18:43','2024-01-11 08:18:43'),(3,'center abou chetwan tlemcen','chatewan tlemcne','043225516','043214741','34.92120407052147','-1.2989621149441444','chetouane',NULL,'2024-01-11 08:18:43','2024-01-11 08:18:43'),(4,'censter mansourah tlemcen','mensourah','043778844','043114414','34.87805834234256','-1.3226279924666933','mansourah',NULL,'2024-01-11 08:18:43','2024-01-11 08:18:43'),(5,'center boudghan tlemcne','tlemccen boudghan','043668899','043225518','34.8734712055189',' -1.3214100233112118','tlemcen',NULL,'2024-01-11 08:18:43','2024-01-11 08:18:43');
/*!40000 ALTER TABLE `consultation_places` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `establishments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `establishments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `acronym` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `establishments` WRITE;
/*!40000 ALTER TABLE `establishments` DISABLE KEYS */;
INSERT INTO `establishments` VALUES (1,'E.H.S','Etablissement Hospitalier spécialisé Mère et Enfant Tlemcen,','ehstlemcen@gmail.com','numero 39, Rue l\'arbi ben m\'hidi, Tlemcen 13550','043221144','043221144',NULL,'2024-01-10 12:03:00','2024-01-10 12:03:00'),(2,'C.H.U','Centre Hospitalo-Universitaire Dr Tidjani Damerdji de Tlemcen','chutlemcen@gmail.com','numero 20, Rue l\'arbi ben m\'hidi, Tlemcen 13000','043221166','043221146',NULL,'2024-01-10 12:03:00','2024-01-10 12:03:00'),(3,'E.P.H.R','Établissement Public Hospitalier Remchi ','ephremchi@gmail.com','remchi tlemcen','043221145','043221163',NULL,'2024-01-10 12:03:00','2024-01-10 12:03:00');
/*!40000 ALTER TABLE `establishments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `general_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `general_settings` WRITE;
/*!40000 ALTER TABLE `general_settings` DISABLE KEYS */;
INSERT INTO `general_settings` VALUES (1,1,'2024-01-10 11:57:03','2024-01-20 11:14:35',NULL);
/*!40000 ALTER TABLE `general_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `size` bigint(20) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `use_case` varchar(255) NOT NULL,
  `imageable_type` varchar(255) NOT NULL,
  `imageable_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `images_imageable_type_imageable_id_index` (`imageable_type`,`imageable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,'65a0451fe27e6-1.png','images/65a0451fe27e6-1.png','http://127.0.0.1:8000/storage/images/65a0451fe27e6-1.png',6829,252,200,1,'letter','App\\Models\\RendezVous',1,'2024-01-11 18:44:31','2024-01-11 18:44:31',NULL),(2,'65a045572fb53-2.png','images/65a045572fb53-2.png','http://127.0.0.1:8000/storage/images/65a045572fb53-2.png',6829,252,200,1,'letter','App\\Models\\RendezVous',2,'2024-01-11 18:45:27','2024-01-11 18:45:27',NULL);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medical_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `opened_by` bigint(20) unsigned NOT NULL,
  `establishment_id` bigint(20) unsigned DEFAULT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `birth_date` date NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tel` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medical_files_opened_by_foreign` (`opened_by`),
  KEY `medical_files_establishment_id_foreign` (`establishment_id`),
  CONSTRAINT `medical_files_establishment_id_foreign` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medical_files_opened_by_foreign` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medical_files` WRITE;
/*!40000 ALTER TABLE `medical_files` DISABLE KEYS */;
INSERT INTO `medical_files` VALUES (1,'si kaddour','haytham','2024-1','oussamasikaddour@gmail.com',17,2,NULL,'1989-06-22','tlemcen 13000','0551658449','2024-01-11 13:59:54','2024-01-11 18:44:31',NULL),(2,'si kaddour','amina','2024-2','oussamasikaddour@gmail.com',17,NULL,NULL,'1989-06-22','tlemcen 13000','0556584125','2024-01-11 20:14:45','2024-01-11 20:14:45',NULL);
/*!40000 ALTER TABLE `medical_files` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (127,'2023_11_14_125138_update_medical_files',2),(128,'2023_11_14_134915_modify_address_column_in_medical_files_table',3),(129,'2023_11_14_135204_modify_address_column_in_medical_files_table',4),(238,'2023_12_11_135107_add_consultation_place_id_to_rendez_vous',6),(293,'2014_10_12_000000_create_users_table',7),(294,'2014_10_12_100000_create_password_reset_tokens_table',7),(295,'2019_05_11_000000_create_otps_table',7),(296,'2019_08_19_000000_create_failed_jobs_table',7),(297,'2019_12_14_000001_create_personal_access_tokens_table',7),(298,'2023_10_03_134404_create_establishments_table',7),(299,'2023_10_03_134509_create_general_settings_table',7),(300,'2023_10_03_134526_create_images_table',7),(301,'2023_10_03_134743_create_medical_files_table',7),(302,'2023_10_03_134801_create_occupations_table',7),(303,'2023_10_03_134813_create_personnel_infos_table',7),(304,'2023_10_03_134909_create_roles_table',7),(305,'2023_10_03_135004_create_services_table',7),(306,'2023_10_03_135241_create_role_user_table',7),(307,'2023_10_04_134713_create_consultation_places_table',7),(308,'2023_10_04_134824_create_plannings_table',7),(309,'2023_10_04_134838_create_planning_days_table',7),(310,'2023_10_08_134900_create_rendez_vous_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `occupations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entitled` varchar(255) NOT NULL,
  `experience` int(11) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `specialty` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `occupations_user_id_foreign` (`user_id`),
  CONSTRAINT `occupations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `occupations` WRITE;
/*!40000 ALTER TABLE `occupations` DISABLE KEYS */;
INSERT INTO `occupations` VALUES (1,'doctor',NULL,'Medicine','general_surgery',NULL,10,'2024-01-11 09:00:17','2024-01-11 12:01:15',NULL),(2,'doctor',NULL,'Medicine','general_surgery',NULL,11,'2024-01-11 09:03:48','2024-01-11 09:03:48',NULL),(3,'doctor',NULL,'Medicine','general_surgery',NULL,12,'2024-01-11 12:02:40','2024-01-11 12:02:40',NULL),(4,'doctor',NULL,'Medicine','general_surgery',NULL,13,'2024-01-11 12:05:19','2024-01-11 12:05:19',NULL),(5,'doctor',NULL,'Medicine','anesthesiology',NULL,14,'2024-01-11 13:26:40','2024-01-11 13:26:40',NULL),(6,'doctor',NULL,'Medicine','anesthesiology',NULL,16,'2024-01-11 13:55:06','2024-01-11 13:55:06',NULL),(7,'doctor',NULL,'Medicine','pediatrics',NULL,37,'2024-01-16 20:41:58','2024-01-16 20:41:58',NULL);
/*!40000 ALTER TABLE `occupations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `validity` int(11) NOT NULL,
  `valid` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `otps_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `otps` WRITE;
/*!40000 ALTER TABLE `otps` DISABLE KEYS */;
INSERT INTO `otps` VALUES (1,'oussamasikaddour@gmail.com','622492',60,0,'2024-01-11 13:58:31','2024-01-11 13:58:48'),(18,'oussamasikaddour@gmail.com','203936',60,0,'2024-01-14 17:55:44','2024-01-14 18:39:47'),(20,'oussamasikaddour@gmail.com','382771',60,0,'2024-01-14 18:59:27','2024-01-14 19:11:29'),(23,'oussamasikaddour@gmail.com','597371',60,1,'2024-01-16 20:38:56','2024-01-16 20:38:56');
/*!40000 ALTER TABLE `otps` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personnel_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personnel_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `last_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `card_number` varchar(255) DEFAULT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `addresses` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personnel_infos_card_number_unique` (`card_number`),
  KEY `personnel_infos_user_id_foreign` (`user_id`),
  CONSTRAINT `personnel_infos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personnel_infos` WRITE;
/*!40000 ALTER TABLE `personnel_infos` DISABLE KEYS */;
INSERT INTO `personnel_infos` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2024-01-10 11:57:03','2024-01-10 11:57:03',NULL),(2,'admin','ehs',NULL,NULL,'1989-06-22',NULL,'0551658449',2,'2024-01-10 12:03:29','2024-01-10 12:03:29',NULL),(4,'admin','EPHR',NULL,NULL,'1988-06-22',NULL,'0551658443',4,'2024-01-10 12:08:46','2024-01-10 12:08:46',NULL),(5,'admin','chu',NULL,NULL,'1987-06-22',NULL,'0552244143',5,'2024-01-10 12:35:46','2024-01-10 12:35:46',NULL),(6,'coord ','chur a',NULL,NULL,'1987-06-22',NULL,'0552447789',6,'2024-01-10 12:38:36','2024-01-10 12:38:36',NULL),(7,'coord ','chur b',NULL,NULL,'1988-06-22',NULL,'0778941422',7,'2024-01-10 12:41:06','2024-01-10 12:41:06',NULL),(8,'coord ','ped ehs',NULL,NULL,'1989-06-22',NULL,'0553614254',8,'2024-01-10 12:53:18','2024-01-10 12:53:18',NULL),(9,'coord','ria',NULL,NULL,'1987-06-22',NULL,'0552664142',9,'2024-01-10 12:56:14','2024-01-10 12:56:14',NULL),(10,'khrbouch','samad',NULL,NULL,'1989-06-22',NULL,'0677254142',10,'2024-01-11 09:00:17','2024-01-11 09:00:17',NULL),(11,'fandi','mustapha',NULL,NULL,'1987-06-22',NULL,'0778452142',11,'2024-01-11 09:03:48','2024-01-11 09:03:48',NULL),(12,'benshla','merwan',NULL,NULL,'1989-05-10',NULL,'0666233445',12,'2024-01-11 12:02:40','2024-01-11 12:02:40',NULL),(13,'belarbi','anoaur',NULL,NULL,'1989-11-11',NULL,'0551658666',13,'2024-01-11 12:05:19','2024-01-11 12:05:19',NULL),(14,'bethar','samir',NULL,NULL,'1974-06-22',NULL,'0551241425',14,'2024-01-11 13:26:40','2024-01-11 13:26:40',NULL),(15,'coord','ria chu',NULL,NULL,'1989-06-22',NULL,'0551658999',15,'2024-01-11 13:39:52','2024-01-11 13:39:52',NULL),(16,'amine ','tachma',NULL,NULL,'1989-06-22',NULL,'0551658424',16,'2024-01-11 13:55:06','2024-01-11 13:55:06',NULL),(17,'oussama','si kaddour',NULL,NULL,'1989-06-22',NULL,'0551658425',17,'2024-01-11 13:58:31','2024-01-11 13:58:31',NULL),(18,'coord','bry',NULL,NULL,'1978-06-22',NULL,'0551658777',18,'2024-01-11 20:28:32','2024-01-11 20:28:32',NULL),(36,'mansouri','djawad',NULL,NULL,'1988-01-22',NULL,'0551658426',36,'2024-01-14 17:55:44','2024-01-14 17:55:44',NULL),(37,'kahwdji','khaddija',NULL,NULL,'1989-06-22',NULL,'0666666666',37,'2024-01-16 20:41:58','2024-01-16 20:41:58',NULL);
/*!40000 ALTER TABLE `personnel_infos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `planning_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planning_days` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `planning_id` bigint(20) unsigned NOT NULL,
  `consultation_place_id` bigint(20) unsigned NOT NULL,
  `day_at` date NOT NULL,
  `number_of_consultation` int(11) NOT NULL,
  `number_of_rendez_vous` int(11) DEFAULT NULL,
  `state` enum('complete','incomplete') NOT NULL DEFAULT 'incomplete',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planning_days_doctor_id_foreign` (`doctor_id`),
  KEY `planning_days_planning_id_foreign` (`planning_id`),
  KEY `planning_days_consultation_place_id_foreign` (`consultation_place_id`),
  CONSTRAINT `planning_days_consultation_place_id_foreign` FOREIGN KEY (`consultation_place_id`) REFERENCES `consultation_places` (`id`) ON DELETE CASCADE,
  CONSTRAINT `planning_days_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `planning_days_planning_id_foreign` FOREIGN KEY (`planning_id`) REFERENCES `plannings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `planning_days` WRITE;
/*!40000 ALTER TABLE `planning_days` DISABLE KEYS */;
INSERT INTO `planning_days` VALUES (1,10,1,2,'2024-01-14',5,NULL,'incomplete',NULL,'2024-01-11 12:09:39','2024-01-11 12:09:39'),(2,11,1,3,'2024-01-17',5,NULL,'incomplete',NULL,'2024-01-11 12:10:01','2024-01-11 12:10:01'),(3,12,2,4,'2024-01-20',3,1,'incomplete',NULL,'2024-01-11 12:12:03','2024-01-11 18:45:27'),(4,13,2,3,'2024-01-20',3,NULL,'incomplete',NULL,'2024-01-11 12:12:17','2024-01-11 12:12:17'),(5,14,4,4,'2024-01-14',3,NULL,'incomplete',NULL,'2024-01-11 13:31:25','2024-01-11 13:31:25'),(6,14,4,4,'2024-01-18',3,NULL,'incomplete',NULL,'2024-01-11 13:31:45','2024-01-11 13:31:45'),(7,16,5,2,'2024-01-14',2,1,'incomplete',NULL,'2024-01-11 13:55:49','2024-01-11 18:44:31'),(8,16,5,3,'2024-01-20',3,NULL,'incomplete',NULL,'2024-01-11 13:55:58','2024-01-11 13:55:58'),(9,13,3,3,'2024-02-10',2,NULL,'incomplete',NULL,'2024-01-14 21:08:37','2024-01-14 21:08:37');
/*!40000 ALTER TABLE `planning_days` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plannings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plannings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `year` int(10) unsigned NOT NULL,
  `month` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `service_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `state` enum('published','not_published') NOT NULL DEFAULT 'not_published',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plannings_service_id_foreign` (`service_id`),
  KEY `plannings_created_by_foreign` (`created_by`),
  CONSTRAINT `plannings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plannings_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plannings` WRITE;
/*!40000 ALTER TABLE `plannings` DISABLE KEYS */;
INSERT INTO `plannings` VALUES (1,2024,1,'planng chur b janvier',6,7,'published',NULL,'2024-01-11 12:08:24','2024-01-11 13:24:23'),(2,2024,1,'planng chur a janvier',5,6,'published',NULL,'2024-01-11 12:11:37','2024-01-11 13:23:35'),(3,2024,2,'planning ped fevrier',5,6,'not_published',NULL,'2024-01-11 12:13:45','2024-01-11 12:13:45'),(4,2024,1,'plannig ria ehs a',9,9,'not_published',NULL,'2024-01-11 13:30:50','2024-01-11 13:30:50'),(5,2024,1,'planning ria chu janvier',10,15,'published',NULL,'2024-01-11 13:55:34','2024-01-11 13:56:16');
/*!40000 ALTER TABLE `plannings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rendez_vous`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rendez_vous` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `planning_day_id` bigint(20) unsigned DEFAULT NULL,
  `consultation_place_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('normal','control') NOT NULL DEFAULT 'normal',
  `day_at` date NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rendez_vous_patient_id_foreign` (`patient_id`),
  KEY `rendez_vous_doctor_id_foreign` (`doctor_id`),
  KEY `rendez_vous_planning_day_id_foreign` (`planning_day_id`),
  KEY `rendez_vous_consultation_place_id_foreign` (`consultation_place_id`),
  CONSTRAINT `rendez_vous_consultation_place_id_foreign` FOREIGN KEY (`consultation_place_id`) REFERENCES `consultation_places` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendez_vous_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendez_vous_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `medical_files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendez_vous_planning_day_id_foreign` FOREIGN KEY (`planning_day_id`) REFERENCES `planning_days` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rendez_vous` WRITE;
/*!40000 ALTER TABLE `rendez_vous` DISABLE KEYS */;
INSERT INTO `rendez_vous` VALUES (1,1,16,7,2,'normal','2024-01-14','anesthesiology',NULL,'2024-01-11 18:44:31','2024-01-11 18:44:31'),(2,1,12,3,4,'normal','2024-01-20','general_surgery',NULL,'2024-01-11 18:45:27','2024-01-11 18:45:27'),(3,1,16,NULL,4,'control','2024-01-26','anesthesiology',NULL,'2024-01-11 21:03:22','2024-01-11 21:03:22');
/*!40000 ALTER TABLE `rendez_vous` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_user_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,2,'2024-01-10 11:57:02','2024-01-10 11:57:02'),(2,1,1,'2024-01-10 11:57:02','2024-01-10 11:57:02'),(3,2,3,'2024-01-10 12:03:33','2024-01-10 12:03:33'),(5,4,3,'2024-01-10 12:08:48','2024-01-10 12:08:48'),(6,5,3,'2024-01-10 12:35:48','2024-01-10 12:35:48'),(7,6,3,'2024-01-10 12:38:39','2024-01-10 12:38:39'),(8,7,3,'2024-01-10 12:41:08','2024-01-10 12:41:08'),(9,8,3,'2024-01-10 12:53:20','2024-01-10 12:53:20'),(10,9,3,'2024-01-10 12:56:15','2024-01-10 12:56:15'),(11,10,3,'2024-01-11 09:00:22','2024-01-11 09:00:22'),(12,11,3,'2024-01-11 09:03:50','2024-01-11 09:03:50'),(13,12,3,'2024-01-11 12:02:43','2024-01-11 12:02:43'),(14,13,3,'2024-01-11 12:05:21','2024-01-11 12:05:21'),(15,14,3,'2024-01-11 13:26:43','2024-01-11 13:26:43'),(16,15,3,'2024-01-11 13:39:55','2024-01-11 13:39:55'),(17,16,3,'2024-01-11 13:55:09','2024-01-11 13:55:09'),(18,17,3,'2024-01-11 13:58:33','2024-01-11 13:58:33'),(19,18,3,'2024-01-11 20:28:35','2024-01-11 20:28:35'),(37,36,3,'2024-01-14 17:55:46','2024-01-14 17:55:46'),(38,37,3,'2024-01-16 20:42:08','2024-01-16 20:42:08');
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'SUPER ADMIN','super_admin','2024-01-10 11:57:01','2024-01-10 11:57:01',NULL),(2,'ADMIN','admin','2024-01-10 11:57:01','2024-01-10 11:57:01',NULL),(3,'USER','user','2024-01-10 11:57:01','2024-01-10 11:57:01',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `establishment_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `head_of_service` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_establishment_id_foreign` (`establishment_id`),
  CONSTRAINT `services_establishment_id_foreign` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,1,'service cci','pediatric_surgery','azzouni samir',NULL,'2024-01-10 12:32:51','2024-01-10 12:32:51'),(2,1,'service gyneco','obstetrics_gynecology','blerabi boumedian',NULL,'2024-01-10 12:32:51','2024-01-10 12:32:51'),(3,1,'service pediatrie','pediatrics','mezzoar',NULL,'2024-01-10 12:32:51','2024-01-10 12:32:51'),(4,1,'service neonat','neonatology','smahi amine',NULL,'2024-01-10 12:32:51','2024-01-10 12:32:51'),(5,2,'service churgie A','general_surgery','bouayed amine',NULL,'2024-01-10 12:38:01','2024-01-10 12:38:01'),(6,2,'service churgie B','general_surgery','khrbouch samad',NULL,'2024-01-10 12:38:01','2024-01-10 12:38:01'),(7,2,'service pediatrie','pediatrics','dib samir',NULL,'2024-01-10 12:38:01','2024-01-10 12:38:01'),(8,2,'service Ophtalmologie','ophthalmology','smahi amine',NULL,'2024-01-10 12:38:01','2024-01-10 12:38:01'),(9,1,'service Ria','anesthesiology','betahar samir',NULL,'2024-01-10 12:55:33','2024-01-10 12:55:33'),(10,2,'service ria','anesthesiology','tachma amine',NULL,'2024-01-11 13:39:25','2024-01-11 13:39:25');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `userable_id` bigint(20) unsigned DEFAULT NULL,
  `userable_type` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'super Admin','superAdmin@gmail.com',NULL,'$2y$10$0VwBOk.pB3b8WTcVZ1Ie1uahqMrUxqJusm33E7XbB77VIcV2b1tba',NULL,'admin',NULL,'2024-01-10 11:57:02','2024-01-10 11:57:02',NULL),(2,'admin ehs','adminehs@gmail.com',NULL,'$2y$10$IbaKtmtpe44x14idG/Y1b.iejOBnw4VASIc8s3xmYACSly1Ql/yqi',1,'admin_establishment',NULL,'2024-01-10 12:03:29','2024-01-10 12:05:41',NULL),(4,'admin EPHR','admineprh@gmail.com',NULL,'$2y$10$Qe0WBADwwoS.KI3CYDQhLu3Am/x1qi5IZ74RuRYcLXy5kSuoCCqrG',3,'admin_establishment',NULL,'2024-01-10 12:08:46','2024-01-10 12:10:07',NULL),(5,'admin chu','adminchu@gmail.com',NULL,'$2y$10$29Wp2tPHtwuYmO2ZbvgZZerv.TjeyWmn6TbkhqoM6URFjymu.eo0.',2,'admin_establishment',NULL,'2024-01-10 12:35:46','2024-01-10 12:36:55',NULL),(6,'coord  chur a','coordchura@gmail.com',NULL,'$2y$10$RL7UarW23SEvzmJbdRTJcORjQ2vcekZX.BZ.ZS3KyeXQKH8CGj1Ly',5,'admin_service',NULL,'2024-01-10 12:38:36','2024-01-10 12:39:51',NULL),(7,'coord  chur b','coordchurb@gmail.com',NULL,'$2y$10$CKzvGkxIZVvjYSux4LO9CespnYT/6cQmSEcXQAUEO0rgd0b/HmHgu',6,'admin_service',NULL,'2024-01-10 12:41:06','2024-01-10 12:43:34',NULL),(8,'coord  ped ehs','coordpedehs@gmail.com',NULL,'$2y$10$L0gsZEoOxXlzTw78O6HdhuAODoFjc6lzjz6RjTC9u4QWsLkLdOdK6',3,'admin_service',NULL,'2024-01-10 12:53:18','2024-01-10 12:54:35',NULL),(9,'coord ria','coordriaehs@gmail.com',NULL,'$2y$10$cLPFavONUiKxv.xxq564m.ec7TiQf9KQW25wMky0hdwFHbTYmw1Uu',9,'admin_service',NULL,'2024-01-10 12:56:14','2024-01-10 12:57:43',NULL),(10,'khrbouch samad','ks@gmail.com',NULL,'$2y$10$TF1uVKZvsNWOlcBfOlH7/OHoc4jRHjD.fZTT3AsNzixsHRluClAT2',2,'doctor',NULL,'2024-01-11 09:00:17','2024-01-11 09:02:18',NULL),(11,'fandi mustapha','fandim@gmail.com',NULL,'$2y$10$crxYnQXleHLiQnjMz5LmuunMkvJq0Dz89lb83qSHOwnWb0h3aQYLi',2,'doctor',NULL,'2024-01-11 09:03:48','2024-01-11 09:05:24',NULL),(12,'benshla merwan','mewanbenshla@gmail.com',NULL,'$2y$10$SM4ePr2G0tYWrPjOxWyi0.XMwk/q3G3iTSBvj58EV1b8nEwMPVGw6',2,'doctor',NULL,'2024-01-11 12:02:40','2024-01-11 12:04:08',NULL),(13,'belarbi anoaur','banoar@gmail.com',NULL,'$2y$10$Etv8Of6qynrZeq2toX53n.TTGyLvAGTZrwkKnZt3X8ttXNXfIBPd2',2,'doctor',NULL,'2024-01-11 12:05:19','2024-01-11 12:07:20',NULL),(14,'bethar samir','bettaharsamir@gmail.com',NULL,'$2y$10$mdyEpCyXRlI7d66l4cez9umk0iSZgkFi358SZndRc35IrurYmlHye',1,'doctor',NULL,'2024-01-11 13:26:40','2024-01-11 13:28:17',NULL),(15,'coord ria chu','coordriachu@gmail.com',NULL,'$2y$10$NQZSG01TGBiZq4PYebtH..9BQYEgWahzg26ytentlV5UDM1TTJjNu',10,'admin_service',NULL,'2024-01-11 13:39:52','2024-01-11 13:39:52',NULL),(16,'amine  tachma','amineTachma@gmail.com',NULL,'$2y$10$qEsO0H4cvUCMpwAT./SsuupnpPXuujmypWFhJyYmRx5l6Yl4GJIPq',2,'doctor',NULL,'2024-01-11 13:55:06','2024-01-11 13:57:48',NULL),(17,'oussama si kaddour','ousssika@gmail.com',NULL,'$2y$10$f4a0mVQew8.bnN.BIzl9/uoPW0.vyvP/wbhV64Itq5VFD.NwY3fZG',1,'user',NULL,'2024-01-11 13:58:31','2024-01-11 13:58:31',NULL),(18,'coord bry','coordbrya@gmail.com',NULL,'$2y$10$TWD8JmKefJMffrwsU7rDh.zb4eAWOajTdUg6cd7kuajkn9.ObfMMS',2,'admin_place_of_consultation',NULL,'2024-01-11 20:28:32','2024-01-11 20:37:18',NULL),(36,'mansouri djawad','mansouriDjawad@gmail.com',NULL,'$2y$10$ox/PNEErxR6kez9YJDr.DerX1qXQ0ze2tGwWrHgPqIpCRu/dBZbzy',1,'user',NULL,'2024-01-14 17:55:44','2024-01-14 19:11:45',NULL),(37,'kahwdji khaddija','oussamasikaddour@gmail.com',NULL,'$2y$10$yMrLNBLNoHIWP44Qk6OWwuNJXnWdoMrFiJMtWKJMR66aZ6AOwH1Ye',1,'doctor',NULL,'2024-01-16 20:41:58','2024-01-16 20:41:58',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

